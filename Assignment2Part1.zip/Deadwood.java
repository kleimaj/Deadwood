/* 
 * Deadwood.java
 * 
 * Contributors: Jacob Kleiman, Eric Eagan, Ryan McGinnis
 * November 2017
 */
import java.util.*;


public class Deadwood {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
